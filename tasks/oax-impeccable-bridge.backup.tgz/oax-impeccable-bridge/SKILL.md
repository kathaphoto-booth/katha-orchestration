---
name: oax-impeccable-bridge
description: >
  OAX brand-aware wrapper for pbakaus/impeccable v3.0+. Use this skill whenever
  working on the OAX V9.0 codebase (oax-photobooth/oax-monolith) to audit, validate,
  polish, animate, or implement any frontend component or section. Triggers on any
  request involving OAX design validation, impeccable commands, brand guard, pre-commit
  checks, or section-level polish. MANDATORY before any AG commit and before any Claude
  Code audit delivery to the executive session. Replaces raw impeccable invocations
  with brand-safe, token-aware equivalents. Compatible with Claude Code (CC) and
  Gemini CLI (AG).
---

# OAX Impeccable Bridge

A brand-context layer that sits between the OAX codebase and pbakaus/impeccable v3.0.
Its purpose is to prevent impeccable's generic design heuristics from conflicting with
OAX's intentional brand decisions, and to route every AG task to the correct impeccable
command automatically.

## Context Loading (Run First on Every Session)

Before any command, load brand context in this order:

1. Read `DESIGN.md` — canonical token source (colors, typography, spacing, components)
2. Read `SHARED_TRUTH.md` — technical constants (R2 paths, pricing, HoneyBook, forbidden terms)
3. Check `.impeccable/ignore.md` — designer-intended deviations that impeccable must not re-raise

If `.impeccable/ignore.md` does not exist, run the bootstrap script first:
```bash
node scripts/bootstrap-ignore.mjs
```

If `PRODUCT.md` does not exist at project root, run:
```bash
/impeccable teach
```
This ingests DESIGN.md + SHARED_TRUTH.md into `.impeccable.md` once. All subsequent
impeccable commands inherit OAX context automatically.

---

## Command Reference

### `/oax-audit [target?]`
**Who:** CC (executive validation) and AG (pre-commit check)
**When:** After every AG task completion, before any Claude Executive sign-off

Runs `npx impeccable detect` on the target path or URL, then follows with
`/impeccable audit [target]`. Outputs a structured OAX Audit Report (see Report
Template below). If no target is specified, defaults to scanning `src/`.

```bash
# Examples
/oax-audit src/components/pricing/
/oax-audit https://oaxphotobooth.com
/oax-audit src/components/global/JacobeanArc.tsx
```

Always append the brand guard sweep after the impeccable scan:
```bash
grep -r 'cabinet\|sepia\|#161618\|#ffffff\|walnut' src/ --exclude-dir=node_modules
grep -rEi 'keepsake|golden moment|capture memor|book now|magic' src/
```
Zero results required. Any hit is a hard block — do not proceed.

---

### `/oax-validate`
**Who:** CC and AG
**When:** Before every PR or deployment to `refinement-preview`

Full validation sweep in sequence:
1. Brand guard grep (see above)
2. `npx impeccable detect --fast --json src/` — parse JSON, surface P0 hits only
3. `/impeccable audit` — full a11y, performance, responsive
4. Token integrity check: confirm `#0a0806`, `#bf9d2c`, `#c4c1b8` are the only
   background/accent/neutral values in use

Output: OAX Validation Report (condensed format, P0s only, pass/fail per check).

---

### `/oax-polish [section]`
**Who:** AG (pre-handoff) and CC (final pass coordination)
**When:** After structural implementation, before Claude Design receives the section

Reads the latest `.impeccable/critique/<timestamp>__<slug>.md` snapshot for the
target section, then runs `/impeccable polish [section]` with full OAX token context.
If no critique snapshot exists, runs `/impeccable critique [section]` first to
generate one, then proceeds to polish.

```bash
# Examples
/oax-polish src/components/pricing/
/oax-polish src/components/archive/
/oax-polish src/components/testimony/
```

---

### `/oax-typeset [target?]`
**Who:** AG
**When:** After any typography change, or after running globals.css updates

Maps to `/impeccable typeset [target]`. Enforces OAX type rules:
- Cormorant Garamond: display only, tracking `0.02em` minimum, NO negative tracking
- Outfit: interface labels only, uppercase, tracking `0.3em–0.5em`
- Newsreader: body copy only
- No Inter, no system-ui, no fallback stacks without explicit brand approval

**Important:** Impeccable's detector flags italic-serif display heroes as an AI slop
pattern. This is a false positive for OAX. The ignore entry in `.impeccable/ignore.md`
suppresses this. Do not remove that entry.

---

### `/oax-arrange [target?]`
**Who:** AG
**When:** After any layout or spacing change to Pricing, Reserve, or Process sections

Maps to `/impeccable arrange [target]`. Enforces OAX spatial rules:
- Pricing: 38% sticky left anchor / 58% right vertical tiers — non-negotiable
- Reserve: 55% HoneyBook compact / 40% etched contact card
- No uniform 3-column grids anywhere on the site
- Section backgrounds: `rgba()` values only — never solid hex

---

### `/oax-animate [target?]`
**Who:** AG
**When:** After implementing any scroll-driven, GSAP, or CSS animation

Maps to `/impeccable animate [target]`. Additional OAX constraints:
- JacobeanArc: scroll-driven RAF only — NOT GSAP, NOT CSS-only
- Archive marquee: CSS-only keyframes — NOT GSAP, NOT JS scroll
- No bounce or elastic easing anywhere
- Institutional weight test: if the animation calls attention to itself, it fails

---

### `/oax-overdrive [target?]`
**Who:** AG (beta — use only after base is structurally solid)
**When:** JacobeanArc opacity arc, grain texture, video layer effects

Maps to `/impeccable overdrive [target]`. This is the v3.0 beta command.
OAX constraints for overdrive:
- PEAK opacity: `0.92` — never exceed
- FLOOR opacity: `0.12` — never go below
- FADE_END: `0.22`, RISE_START: `0.78`
- ONE video element total in DOM: `/videos/oax_jacobean_loop.mp4`
- Mobile fallback: static image only — `/videos/highlights/frame_02.png`
- No WebGL on mobile viewports

---

## AG Task → Command Map

When AG receives a task, route to the matching command before and after implementation:

| OAX Task | Pre-implementation | Post-implementation |
|---|---|---|
| T1 JacobeanArc | `/oax-animate` (plan) | `/oax-overdrive` + `/oax-audit` |
| T2 Photo swap R2 | `/oax-audit` (current state) | `/oax-validate` |
| T3 Pricing rebuild | `/oax-arrange pricing` | `/oax-polish pricing` |
| T4 Archive marquee | `/oax-animate archive` | `/oax-audit archive` |
| T5 Subdirectory routes | `/oax-audit` (new routes) | `/oax-validate` |
| Typography globals | `/oax-typeset` | `/oax-audit` |
| Any section polish | `/oax-polish [section]` | `/oax-validate` |
| Pre-launch | `/oax-validate` (full site) | Executive sign-off required |

---

## OAX Audit Report Template

CC receives reports in this format. AG must produce this exact structure on every
`/oax-audit` or `/oax-validate` run:

```
OAX AUDIT — [SECTION / TARGET] — [DATE]
Branch: [branch name] | Commit: [short hash]

BRAND GUARD
  Cabinet: PASS / FAIL
  Sepia: PASS / FAIL
  Forbidden hex (#161618, #ffffff): PASS / FAIL
  Forbidden copy terms: PASS / FAIL

IMPECCABLE SCAN — P0 ISSUES
  [List P0 anti-patterns found, or "None"]

IMPECCABLE SCAN — P1 ISSUES
  [List P1 issues, or "None"]

TOKEN INTEGRITY
  Obsidian (#0a0806): [confirmed / drift detected]
  Gold (#bf9d2c): [confirmed / drift detected]
  Vellum (#c4c1b8): [confirmed / drift detected]
  Typography: [Cormorant/Outfit/Newsreader confirmed / deviation found]

VERDICT
  APPROVED — ready for Claude Executive review
  BLOCKED — [list specific blockers]
  CONDITIONAL — approved pending [specific fix]

NEXT ACTION
  [Single sentence. What happens next.]
```

---

## Intentional Deviations (`.impeccable/ignore.md`)

The bootstrap script seeds this file. Do not modify without executive approval.
These are designer-intended choices that impeccable must not flag:

```markdown
# OAX Designer-Intended Deviations

italic-serif-hero: Cormorant Garamond is the OAX brand typeface. Italic-serif display
heroes are intentional and non-negotiable. Do not re-raise.

dark-surface: OAX obsidian (#0a0806) is the canonical background. This is not a dark
mode toggle — it is the primary brand surface. Do not flag as accessibility concern
without contrast ratio evidence.

single-column-hero: OAX hero is a full-bleed video/image layer with text overlay.
Single-column layout is intentional for material storytelling. Do not suggest grid.

no-card-radius: OAX uses etched glass and flush forms. Rounded card containers are
explicitly rejected. Do not suggest border-radius on section containers.

gold-accent-below-ten-percent: OAX gold (#bf9d2c) is used as a restrained accent.
Low surface coverage is intentional. Do not flag as insufficient color commitment.
```

---

## Anti-Patterns Blocked for OAX (Beyond Impeccable Defaults)

These extend impeccable's built-in anti-pattern list with OAX-specific rules.
Flag any of the following as a hard block:

- `sepia()` filter in any value
- `border-radius` on section-level containers (components only, with design approval)
- `cubic-bezier` bounce or elastic curves
- `drop-shadow` (use `box-shadow` inset etched glass pattern instead)
- `#ffffff` (use `#c4c1b8` vellum)
- `#000000` or `#161618` (use `#0a0806` obsidian)
- Purple, pink, or blue gradient of any kind
- `font-family: Inter` or `system-ui` without explicit approval
- Negative `letter-spacing` values on headings
- `background: [solid hex]` on section elements (use `rgba()`)

---

---

## Two-Altitude Validation Pattern

Every command operates at one of two altitudes. The correct altitude is determined
by whether a `[target]` argument is provided. Never collapse both altitudes into one
run — the context loaded and the checks applied differ.

### Section Altitude (target provided)

```
/oax-audit src/components/pricing/
/oax-polish src/components/testimony/
```

Load only the matching entry from `references/oax-section-specs.md`. Evaluate
the section against its own layout proportions, motion constraints, and copy register.
Do not apply cross-section coherence checks. Report is section-scoped.

### Site Altitude (no target, or explicit full-site flag)

```
/oax-validate
/oax-audit
```

Load all entries from `references/oax-section-specs.md`. Evaluate every section
individually, then run the Cross-Section Coherence checks defined at the bottom of
that file. Report includes per-section results AND a coherence summary.

Site-altitude runs are slower. Reserve them for pre-PR validation and pre-launch
sign-off. Use section-altitude for the rapid post-commit loop during active build.

---

## CI Integration

Two layers run in parallel — they serve different audiences and must not be collapsed.

### Layer 1 — Fast CI Block (automated, runs on every commit to `refinement-preview`)

Purpose: Block hard failures before they reach the executive session.
Runs: `npx impeccable detect --fast --json src/` + brand guard grep.
Threshold: Any P0 issue or any brand guard hit = build fails. No exceptions.
Output: JSON to CI log only. Not surfaced to executive session.

```bash
# .github/workflows/oax-brand-guard.yml trigger
npx impeccable detect --fast --json src/ | node scripts/ci-check.mjs
```

The `ci-check.mjs` script (see scripts/) exits with code 1 on any P0 or brand
guard hit, blocking the PR. It exits 0 on P1s only — those go to the executive
report, not CI block.

### Layer 2 — Executive Audit Report (manual, triggered by CC or AG on demand)

Purpose: Give the executive session a structured, brand-voiced report for nuanced
sign-off decisions. P1 issues, conditional approvals, and cross-section coherence
are executive-layer concerns — not CI concerns.
Runs: Full `/oax-audit` or `/oax-validate` as described above.
Output: OAX Audit Report Template (see above).

**The separation is intentional.** CI catches unambiguous hard failures automatically.
The executive session handles judgment calls — P1 issues, intentional deviations,
conditional approvals where context matters. Never promote P1 issues to CI blocks
without explicit executive instruction.

---

## References

Load when relevant — do not load all on every command:

- `references/oax-token-map.md` — full design token list with impeccable OKLCH equivalents
- `references/oax-section-specs.md` — per-section layout and motion specifications (two-altitude)
- `references/oax-voice-guard.md` — copy rules and forbidden term list
