#!/usr/bin/env node
// ci-check.mjs
// Reads impeccable detect --fast --json output from stdin, runs brand guard grep,
// exits 1 on any P0 issue or brand guard hit. Exits 0 on P1s only.
// P1 issues are logged to stdout for inclusion in the executive audit report.
//
// Usage (in CI):
//   npx impeccable detect --fast --json src/ | node scripts/ci-check.mjs

import { execSync } from 'child_process';
import { readFileSync } from 'fs';

// --- Brand Guard ---
const FORBIDDEN_PATTERNS = [
  { grep: 'cabinet', label: 'cabinet (use "booth")' },
  { grep: 'sepia', label: 'sepia filter' },
  { grep: '#161618', label: 'wrong dark hex (#161618 → use #0a0806)' },
  { grep: '#ffffff', label: 'pure white (use #c4c1b8 vellum)' },
  { grep: 'walnut', label: 'wrong material (walnut)' },
  { grep: 'hello@oaxphotobooth', label: 'fabricated email (hello@oaxphotobooth.com)' },
];
const FORBIDDEN_REGEX = 'keepsake|golden moment|capture memor|book now|magic';

let hardBlocks = [];
let p1Issues = [];

// Run brand guard
for (const { grep, label } of FORBIDDEN_PATTERNS) {
  try {
    const result = execSync(
      `grep -r '${grep}' src/ --exclude-dir=node_modules --include='*.tsx' --include='*.ts' --include='*.jsx' --include='*.css' -l 2>/dev/null`,
      { encoding: 'utf8' }
    ).trim();
    if (result) {
      hardBlocks.push(`BRAND GUARD FAIL: "${label}" found in: ${result.replace(/\n/g, ', ')}`);
    }
  } catch {
    // grep exits 1 when no match — that's a pass
  }
}

try {
  const regexResult = execSync(
    `grep -rEi '${FORBIDDEN_REGEX}' src/ --exclude-dir=node_modules --include='*.tsx' --include='*.ts' --include='*.jsx' -l 2>/dev/null`,
    { encoding: 'utf8' }
  ).trim();
  if (regexResult) {
    hardBlocks.push(`BRAND GUARD FAIL: Forbidden copy terms found in: ${regexResult.replace(/\n/g, ', ')}`);
  }
} catch {
  // pass
}

// Read impeccable JSON from stdin
let impeccableOutput = '';
process.stdin.setEncoding('utf8');
process.stdin.on('data', chunk => { impeccableOutput += chunk; });

process.stdin.on('end', () => {
  let issues = [];

  if (impeccableOutput.trim()) {
    try {
      const parsed = JSON.parse(impeccableOutput);
      issues = parsed.issues || parsed.results || [];
    } catch {
      // Non-JSON output — log and continue
      process.stderr.write('ci-check: Could not parse impeccable JSON output. Skipping scan results.\n');
    }
  }

  // Classify impeccable issues by severity
  for (const issue of issues) {
    const severity = (issue.severity || issue.level || '').toLowerCase();
    const message = `${issue.rule || issue.id || 'unknown'}: ${issue.message || issue.description || ''} (${issue.file || 'unknown file'})`;

    if (severity === 'error' || severity === 'p0') {
      hardBlocks.push(`IMPECCABLE P0: ${message}`);
    } else {
      p1Issues.push(`IMPECCABLE P1: ${message}`);
    }
  }

  // Output results
  if (p1Issues.length > 0) {
    process.stdout.write('\n── P1 Issues (executive review, not blocking) ──\n');
    p1Issues.forEach(i => process.stdout.write(`  ${i}\n`));
  }

  if (hardBlocks.length > 0) {
    process.stderr.write('\n── HARD BLOCKS (build failed) ──\n');
    hardBlocks.forEach(b => process.stderr.write(`  ${b}\n`));
    process.stderr.write(`\n${hardBlocks.length} hard block(s) detected. Resolve before merging.\n`);
    process.exit(1);
  }

  process.stdout.write('\nBrand guard: PASS. No P0 issues detected.\n');
  if (p1Issues.length > 0) {
    process.stdout.write(`${p1Issues.length} P1 issue(s) logged for executive review.\n`);
  }
  process.exit(0);
});
