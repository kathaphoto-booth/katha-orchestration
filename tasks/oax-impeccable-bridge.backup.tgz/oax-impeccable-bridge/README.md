# OAX Impeccable Bridge

Version: 1.0.0 | Compatible with: pbakaus/impeccable v3.0+ | Harnesses: Claude Code + Gemini CLI (AG)

## Activation (two commands, run once)

```bash
cd oax-photobooth/oax-monolith

# 1. Install impeccable into the repo
npx skills add pbakaus/impeccable

# 2. Activate OAX bridge — writes .impeccable.md + .impeccable/ignore.md
node .claude/skills/oax-impeccable-bridge/scripts/bootstrap-ignore.mjs
```

That's it. No `/impeccable teach` required. Brand context is written deterministically
from locked OAX token values, not AI-inferred. Both CC and AG sessions pick it up
immediately.

## File Structure

```
oax-impeccable-bridge/
├── SKILL.md                        ← Commands, routing, audit report template
├── references/
│   ├── oax-token-map.md            ← Design tokens with OKLCH equivalents
│   ├── oax-section-specs.md        ← Per-section specs + cross-section coherence checks
│   └── oax-voice-guard.md          ← Copy rules and forbidden term list
└── scripts/
    ├── bootstrap-ignore.mjs        ← One-command activation (writes both context files)
    └── ci-check.mjs                ← CI P0 blocker (reads impeccable JSON + brand guard)
```

## Command Quick Reference

| Command | Who | When |
|---|---|---|
| `/oax-audit [section]` | CC + AG | After every AG task |
| `/oax-validate` | CC + AG | Before every PR |
| `/oax-polish [section]` | AG | Pre-handoff to Claude Design |
| `/oax-typeset [target]` | AG | After typography changes |
| `/oax-arrange [target]` | AG | After layout/spacing changes |
| `/oax-animate [target]` | AG | After animation changes |
| `/oax-overdrive [target]` | AG (beta) | JacobeanArc + grain effects only |

## Two Altitudes

Section: `/oax-audit pricing` — loads only the pricing spec, evaluates in isolation.
Site: `/oax-validate` — loads all section specs + cross-section coherence checks.

Use section altitude during the active build loop. Site altitude before PRs and launch.

## CI Layer

Fast regex + impeccable detect runs automatically on every commit to `refinement-preview`.
P0 hits and brand guard failures block the build. P1 issues route to the executive
audit report for sign-off — they never block CI automatically.
