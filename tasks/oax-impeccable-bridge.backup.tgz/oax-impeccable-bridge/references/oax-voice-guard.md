# OAX Voice Guard — Copy Rules and Forbidden Terms

Load when running `/oax-audit` on any section that contains copy, or when AG is
writing placeholder or final copy for any component.

## Brand Voice

OAX voice is institutional premium. Consultative, not chatty. Confident, not bravado.
The booth speaks for itself — copy provides context and confidence, not persuasion.

Think: a hotel concierge who has done this a thousand times and will not oversell it.

## Forbidden Terms (Hard Block — Zero Tolerance)

Any of the following in `src/` or public-facing copy triggers a BLOCKED verdict:

- `cabinet` — always "booth"
- `walnut` — wrong material
- `memories`, `keepsakes`, `golden moments` — sentimental tropes
- `capture memories`, `capture the moment` — cliché
- `book now` — urgency tactic, incompatible with consultative tone
- `magic`, `magical` — too casual
- `fun` as a standalone brand promise
- `affordable`, `budget`, `cheap` — wrong positioning
- `perfect for your event` — generic
- `stunning`, `amazing`, `incredible` — copy inflation

## Required Tone Markers

Copy must pass this filter before approval:

- Does it treat the reader as an adult making a considered purchase? (Required)
- Does it lead with the object (the booth, the oak, the craft) before the emotion? (Required)
- Is the CTA consultative rather than urgent? ("Reserve your date" not "Book now") (Required)
- Is the pricing transparent and un-hedged? (Required for pricing section)

## Headline Register

H1 / H2 headlines should be declarative statements, not questions or promises.
Examples of approved register:
- "Handcrafted for the Occasion" ✓
- "Premium photo booth rental in Los Angeles & Orange County" ✓
- "One booth. Two brothers. Yours for the evening." ✓

Examples of rejected register:
- "Ready to make memories?" ✗
- "Your perfect event starts here" ✗
- "Experience the magic of OAX" ✗

## CTA Copy Rules

- Primary CTA: "Reserve your date" or "Inquire"
- Secondary CTA: Direct contact (phone/email) — never "Learn more"
- No competing CTAs in the same viewport
- HoneyBook form label: "Name", "Email", "Event Date" — no other field labels public-facing
