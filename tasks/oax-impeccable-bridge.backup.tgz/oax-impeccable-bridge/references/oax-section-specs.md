# OAX Section Specifications

Load this file when running `/oax-arrange`, `/oax-audit`, or `/oax-validate` on
any named section. Each entry defines the layout proportions, motion constraints,
copy register, and success criteria that impeccable must evaluate against — not
against its generic heuristics.

When operating at full-site altitude, load all entries and additionally evaluate
the Cross-Section Coherence checks at the bottom of this file.

---

## HERO

**Layout:** Full-bleed, single column. Video layer behind text overlay.
**Video:** `/videos/oax_jacobean_loop.mp4` — one element, no duplicates in DOM.
**Mobile fallback:** `/videos/highlights/frame_02.png` — static image, no video.
**Opacity arc:** JacobeanArc — PEAK 0.92 / FLOOR 0.12 / FADE_END 0.22 / RISE_START 0.78.
**Section background:** `rgba()` only — never solid hex.
**CTA:** Single. "Reserve your date" or "Inquire." No secondary CTA in viewport.
**Copy register:** Declarative. Tagline: "Handcrafted for the Occasion."
**H2:** "Premium photo booth rental in Los Angeles & Orange County."
**Anti-patterns to flag:** Bounce on CTA, gradient overlay instead of JacobeanArc opacity,
second CTA competing for attention, any video element beyond the single registered element.

---

## INSTALLATION (Archive — Main Scroll)

**Layout:** Full-width horizontal marquee. CSS-only keyframes — NOT GSAP, NOT JS scroll.
**Content:** Booth-in-venue photos only. No guest faces. No event names. No text labels.
**Motion:** Continuous left scroll, 40s linear, pause-on-hover via `animation-play-state`.
**Implementation:** Duplicate photo array in markup for seamless loop.
**Section background:** `rgba()` only.
**Anti-patterns to flag:** GSAP on the marquee, JS-driven scroll position, event names
or guest faces in photos, any non-CSS motion implementation.

---

## PRICING

**Layout:** Two-column asymmetric. 38% sticky left anchor / 58% right vertical tier stack.
**NOT permitted:** 3-column equal-width grid. Uniform card layout. Centered pricing table.
**Tiers (vertical stack, right column):**
  - Classic Oak — $1,499 / 3hr
  - Signature — $2,100 / 4hr
  - Heritage — $2,950 / 5hr
**Price gaps visible:** +$601 / +$850 — editorial contrast is intentional.
**Add-ons:** Defined in SHARED_TRUTH.md ADD_ONS object. Display below tiers.
**Retainer:** Defined in SHARED_TRUTH.md RETAINER object.
**Copy register:** No urgency language. Transparent. Un-hedged. Prices visible without
interaction — no "contact for pricing" pattern.
**Anti-patterns to flag:** Hidden pricing, "starting from" hedge language, equal-width
3-column grid, pricing behind a CTA click.

### Booth Panel (Pricing subsection)

The booth panel is an expandable accordion that lives below the three-tier vertical
stack in the 58% right column. It documents the physical enclosure and is not a
pricing tier — it must not be styled or positioned as a fourth tier.

**Collapsed state:** 72px fixed-height bar. Displays "Dark Walnut Enclosure" label
(Outfit uppercase, tracking 0.4em) and a single expand chevron. Background:
`rgba(10, 8, 6, 0.6)`. No pricing data. No CTA. No sub-labels visible.

**Expanded state:** Sub-panel reveals three static spec lines (dimensions, finish,
weight) plus the refiner-corrected booth photo (`master_2.png` or `master.png`
per event context). Photo proportions locked at 4:3 — do not crop to square. Spec
lines: Newsreader body, no Outfit labels inside the expanded body. The expand
chevron rotates 180° on open.

**Expansion animation:** `imperialEase cubic-bezier(0.16, 1, 0.3, 1)`, duration
380ms. Height animates from 72px to auto via max-height transition. NO bounce, NO
elastic, NO spring physics. CSS-only — no GSAP, no JS animation on this element.

**Sticky container boundary:** The booth panel scrolls with the right column. It
does NOT participate in the 38% sticky left anchor behavior. The sticky boundary
applies only to the left-column editorial stack (section label + pricing narrative).
The booth panel must remain in normal document flow within the right column.

**Anti-patterns to flag:** Booth panel rendered as a fourth pricing tier, photo
cropped to square or 16:9, GSAP or JS animation on the expand/collapse, panel
participating in left-column sticky scroll, spec lines using Outfit labels inside
the expanded body, CTA or "Inquire" link inside the panel.

---

## ABOUT

**Voice:** Owner-attendant model. Lead with the object (the booth, the oak), close with
people. Healthcare background is context, not the headline.
**Props rule:** Guest photo prints in the tray are the only permitted props in any
photography or illustration. No prop baskets, signs, or accessories.
**Anti-patterns to flag:** "Two brothers" leading the section before establishing the
booth, props visible beyond guest photo prints, bravado tone.

---

## PROCESS

**Reference:** brandium.nl/approach — structural reference only, discard colors and effects.
**Texture:** 21st.dev PerspectiveMarquee pattern.
**Body copy motion:** MagicText (motion/react).
**Section background:** `rgba()` only.
**Anti-patterns to flag:** Generic numbered steps with icon tiles, flat static layout
without the brandium structural weight, bounce or elastic on any step transition.

---

## TESTIMONY

**Pattern:** fifthanddune.com — full-length verbatim quotes, no truncation.
**NOT permitted:** Star ratings. Truncated "read more" quotes. Avatar photos. Carousel.
**Layout:** Vertical stack of full-length quotes. No modal. No interaction required to
read the complete testimonial.
**This section is separate from Archive.** Do not merge, combine, or rename as "Evidence."
**Anti-patterns to flag:** Star ratings of any kind, "Read more" truncation, quote cards
in a carousel, any suggestion to merge with Archive.

---

## ARCHIVE (Gallery — /gallery subdirectory)

**Main scroll:** Installation marquee (see INSTALLATION above).
**Subdirectory `/gallery`:** Private event galleries with access codes and FotoShare embeds.
**This section is separate from Testimony.** Architectural decision is locked. Do not
propose merging into an "Evidence." section under any framing.
**Anti-patterns to flag:** Guest faces in the main scroll marquee, event names in the
marquee, any suggestion to merge with Testimony.

---

## RESERVE

**Layout:** 55% HoneyBook compact form / 40% etched contact card.
**Mobile:** Contact card renders first, HoneyBook form below.
**Public form fields:** Name, Email, Event Date — exactly three fields, no exceptions.
**HoneyBook 12-field smart file:** Sent via human reply only — never exposed on the
public website.
**Styling:** `components.card-etched` and `components.card-contact` from DESIGN.md.
**Anti-patterns to flag:** More than 3 fields on the public form, HoneyBook 12-field
form embedded publicly, contact card below the form on mobile, drop shadows instead
of etched glass treatment.

---

## FAQ

**Collapse pattern:** Institutional weight — no bounce, no elastic easing.
**Easing:** `imperialEase cubic-bezier(0.16, 1, 0.3, 1)` only.
**Anti-patterns to flag:** Bounce on collapse, accordion with icon animations that call
attention to themselves, more than one FAQ open at a time (if interactive).

---

## FOOTER

**Required data (NAP):** 424-215-1450 | oaxphotobooth@gmail.com | @oaxphotobooth | oaxphotobooth.com
**Forbidden:** hello@oaxphotobooth.com — purge on sight wherever found.
**Schema markup:** Verify against SHARED_TRUTH.md schema object before production.
**Anti-patterns to flag:** hello@oaxphotobooth.com present anywhere, missing NAP fields,
schema markup absent or mismatched.

---

## V3 Component Reference Map

This table documents which 21st.dev components are locked to which sections as of
V3. Apply each component only to its designated section. Do not migrate a component
to a different section without executive approval.

| Component | Section | Implementation constraint |
|---|---|---|
| BlurTextAnimation | HERO | Hero tagline reveal on initial load. CSS blur + opacity entrance. One instance. |
| MagicText | PROCESS | Section headings only. Per-character scroll-driven reveal. No use in PRICING, TESTIMONY, or ABOUT. |
| PerspectiveMarquee | PROCESS | Background marquee strip with 3D depth. Structural, not decorative. No use in INSTALLATION marquee. |
| ParallaxScroll | PROCESS | Depth layering between grain / marquee / MagicText. Scoped to Process section container. |
| ExpandablePanel | PRICING | Booth panel accordion. Collapsed 72px → expanded sub-panel. Right column only. Not a pricing tier. |
| CTAMarquee (blur rail) | CTA / RESERVE | Blur-edge masking via webkit-mask-image. No sepia. Permitted in CTA band above Reserve. |

**Rules for this table:**
- INSTALLATION uses CSS-only keyframe marquee — NOT PerspectiveMarquee.
- MagicText must not appear in HERO (would conflict with BlurTextAnimation).
- ExpandablePanel must not appear in FAQ (FAQ uses its own imperialEase collapse; no shared component).
- Adding a 21st.dev component to a section not listed here requires a new ignore entry in `.impeccable/ignore.md` and explicit executive sign-off.

---

## Cross-Section Coherence Checks (Full-Site Altitude Only)

When `/oax-validate` or `/oax-audit` runs across the full site, evaluate these
cross-cutting concerns in addition to individual section checks:

**Color consistency:** `#0a0806` obsidian is the only section background base. Any
section using a different background color without `rgba()` wrapping is a P0 issue.

**Type scale consistency:** Cormorant Garamond appears only in display roles (H1, H2,
pull quotes). Outfit appears only in labels and interface copy. Newsreader appears only
in body paragraphs. Any cross-contamination is a P1 issue.

**Motion vocabulary coherence:** JacobeanArc opacity arc applies globally to the scroll
experience. Individual section animations (marquee, process motion, FAQ collapse) must
not introduce easing curves that conflict with `imperialEase`. Any bounce or elastic
curve anywhere is a P0 issue.

**CTA hierarchy:** Only one primary CTA is dominant at any scroll position. Competing
CTAs in the same viewport are a P1 issue. No "Book now" language appears anywhere — P0.

**Section order integrity:** Confirm site structure matches the locked order:
Hero → Installation → Pricing → About → Process → Testimony → Archive → Reserve → FAQ → Footer.
Any deviation from this order is a P0 issue.

**Testimony / Archive separation:** These are two distinct sections and must remain so.
Any merged "Evidence." pattern or combined section is a P0 architectural violation.
