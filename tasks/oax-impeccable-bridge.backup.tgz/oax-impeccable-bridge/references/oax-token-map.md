# OAX Token Map — Impeccable Equivalents

This file maps OAX design tokens to impeccable's color strategy and typography
system. Load when running `/oax-typeset`, `/oax-arrange`, or any color-related audit.

## Color Strategy

OAX uses impeccable's **Restrained** color commitment:
- Tinted neutrals dominate (obsidian surface, vellum text)
- One accent ≤10% surface coverage (gold)
- No color strategy switching mid-session

| OAX Token | Hex | Impeccable Role |
|---|---|---|
| obsidian | #0a0806 | Primary background / dark surface |
| gold | #bf9d2c | Single accent (≤10% surface) |
| vellum | #c4c1b8 | Body text / tinted neutral |

OKLCH equivalents (use when impeccable requests OKLCH values):
- obsidian → `oklch(8% 0.008 60)` (near-black, warm hue tint)
- gold → `oklch(58% 0.09 75)` (mid-lightness, moderate chroma, amber)
- vellum → `oklch(78% 0.006 65)` (light, low chroma, warm)

## Typography System

| Role | Family | Weight | Tracking | Impeccable Category |
|---|---|---|---|---|
| Display / H1 / H2 | Cormorant Garamond | 300–400 | 0.02em minimum | Serif display |
| Interface / Labels | Outfit | 400–500 | 0.3em–0.5em uppercase | Geometric sans |
| Body copy | Newsreader | 400 | default | Serif body |

Impeccable's font reflex-reject list includes "editorial-typographic" as a
second-order reflex pattern. OAX intentionally uses editorial-typographic treatment.
This is registered in `.impeccable/ignore.md` and must not be re-raised.

## Motion Tokens

| Token | Value | Impeccable Mapping |
|---|---|---|
| imperialEase | cubic-bezier(0.16, 1, 0.3, 1) | Custom ease — not bounce, not elastic |
| JacobeanArc PEAK | 0.92 opacity | Overdrive ceiling |
| JacobeanArc FLOOR | 0.12 opacity | Overdrive floor |
| Archive marquee | CSS keyframes, 40s linear | animate — CSS-only |

## Refiner Filter

Applied to all photos: `contrast(1.12) brightness(0.92) saturate(0.78)`
ZERO sepia in any form. This is a hard brand rule, not a preference.

## Spatial Constants

- Pricing left column: 38% width, sticky
- Pricing right column: 58% width, vertical tier stack
- Reserve HoneyBook panel: 55% width
- Reserve contact card: 40% width
- Section gaps: reference `DESIGN.md → spacing.*` exclusively
